export async function handler(event, context) {
  try {
    const r = await fetch("https://api.dexscreener.com/latest/dex/pairs/solana");
    const data = await r.json();
    return {
      statusCode: 200,
      body: JSON.stringify(data),
    };
  } catch (e) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "API hata", details: e.message }),
    };
  }
}
